<?php
session_start();
include '../connection.php';

if(!isset($_SESSION['seller_id'])){
	die("Login Required! <a href='"."../loginform.php'>Click Here</a>"); 


}
$idtodelete=$_POST['itemid'];

$deletequery="Delete from product where id=$idtodelete";
echo "Processing";
mysqli_query($con,$deletequery);

header('location:myitems.php');
?>