<?php
session_start();
include '../connection.php';

if(!isset($_SESSION['seller_id'])){
	die("Login Required! <a href='"."../loginform.php'>Click Here</a>"); 
}
$myid=$_SESSION['seller_id'];
$getallitems="Select * from product where seller_id=$myid";

$getallitemsvalue=mysqli_query($con,$getallitems);
if(!$getallitems){
	die(mysqli_error($con));
}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table id="myItemsTable">
<tr>
<th>Photo</th>
<th>Name</th>
<th>Price</th>
<th>Quantity</th>
<th>Options</th>
</tr>
<?php
foreach ($getallitemsvalue as $value) { ?>
<tr>
<td><img src="<?php print_r($value["photo"])?>"></td>
<td><?php print_r($value['name']) ?></td>
<td><?php print_r($value['price']) ?></td>
<td><?php print_r($value['quantity']) ?></td>
<td>
	<form method="POST" action="additem.php?option=2">
	<input type="hidden" name="itemid" value="<?php print_r($value['id'])?>">
	<input type="submit" name="editbutton" value="Edit">
	</form>
	<form method="POST" action="deleteitem.php">
	<input type="hidden" name="itemid" value="<?php print_r($value['id'])?>">
	<input type="submit" name="deletebutton" value="Delete">
	</form>
	<form method="POST" action="activeinactive.php">
	<input type="hidden" name="itemid" value="<?php print_r($value['id'])?>">
	<input type="submit" name="actioninactive" value="Active/Inactive">
	</form>
</td>	
</tr>
<?php
}
?>
	
</table>

</body>
</html>