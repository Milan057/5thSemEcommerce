<?php
session_start();
if(!isset($_SESSION['seller_id'])){
	die("Login Required! <a href='"."../loginform.php'>Click Here</a>"); 
}
$getseller_id=$_SESSION['seller_id'];
include '../connection.php';
$path=__DIR__;
$getcategory="Select * from categories";
$category_value=mysqli_query($con,$getcategory);
if(!$category_value){
	die(mysqli_error($con));


}
if($_GET["option"]==2){
	echo"<h1>Edit Item</h1>";
	//if(!$_POST['itemid']){
	//	header("location:myitems.php");
	//}
	if(isset($_POST['itemid'])){
		$_SESSION['itemid']=$_POST['itemid'];
	}
	$idtoedit=$_SESSION['itemid'];
	$olddata="SELECT * from product where id=$idtoedit";
	$olddatavalue=mysqli_query($con,$olddata);
	$fetchedoldvalue=mysqli_fetch_assoc($olddatavalue);

	$name=$fetchedoldvalue['name'];
	$oldphoto=$fetchedoldvalue['photo'];

	$price=$fetchedoldvalue['price'];
	$quantity=$fetchedoldvalue['quantity'];
	$category_id=$fetchedoldvalue['category_id'];
	$seller_id=$fetchedoldvalue['seller_id'];
	$tag=$fetchedoldvalue['tag'];
	$expiry_date=$fetchedoldvalue['expiry_date'];
	$description=$fetchedoldvalue['description'];

}else{
	echo"<h1>Add Item</h1>";
}
if(isset($_POST["saveitem"])){
	move_uploaded_file($_FILES["photo"]["tmp_name"],$path."/itemsphoto"."/".$_FILES["photo"]["name"]);


	$name=$_POST["name"];
	$photo='/ecommerce/seller/itemsphoto/'.$_FILES["photo"]["name"];
	if($_FILES["photo"]["name"]==""){
		$photo=$oldphoto;
	}
	$price=$_POST["price"];
	$quantity=$_POST["quantity"];
	$category_id=$_POST["category_id"];
	$seller_id=$getseller_id;
	$tag=$_POST["tag"];
	$expiry_date=$_POST["expiry_date"];
	$description=$_POST["description"];

if($_GET["option"]==2){
$insertitems="Update product SET name='$name',photo='$photo',seller_id='$seller_id',category_id='$category_id',price='$price',tag='$tag',quantity='$quantity',expiry_date='$expiry_date',description='$description' where id=$idtoedit";
echo $insertitems;
}else{
	$insertitems="Insert into product(name,photo,seller_id,category_id,price,tag,quantity,expiry_date,description,status) values('$name','$photo','$seller_id','$category_id','$price','$tag','$quantity','$expiry_date','$description',1);";
}
echo $insertitems;
	$insertitems_value=mysqli_query($con,$insertitems);
	if(!$insertitems_value){
		die(mysqli_error($con));
	}


	
//header("location:../success.php");

}


?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php if($_GET['option']!=2){ ?>
<form method="POST" enctype="multipart/form-data">
<label>ItemName*</label>
<input type="text" name="name" required>	
<label>Photo*</label>
<input type="file" name="photo" accept="image/x-png,image/jpeg" required>	
<label>Price*</label>
<input type="text" name="price" required>
<label>Quantity*</label>
<input type="text" name="quantity" required>
<label>Category*</label>
<select name="category_id" id="category_id" required>
	<?php
	foreach($category_value as $value){?>
	<option value=<?php print_r($value["id"]); ?> ><?php print_r($value["category_name"]); ?></option>
<?php	
}
?>	
	
</select>
<label>Expiry Date</label>
<input type="date" name="expiry_date">
<label>Description</label>
<input type="text" name="description" required>
<label>Tags*</label>
<input type="text" name="tag">
<input type="submit" name="saveitem" value="Add Item">
</form>
<?php }else{?>

<!--Form for edit condition!-->
<form method="POST" enctype="multipart/form-data">
<label>ItemName*</label>
<input type="text" name="name" value="<?php echo $name ?>"required>	
<label>Photo*</label>
<input type="file" name="photo" accept="image/x-png,image/jpeg">	
<label>Price*</label>
<input type="text" name="price" value="<?php echo $price ?>" required>
<label>Quantity*</label>
<input type="text" name="quantity"value="<?php echo $quantity ?>" required>
<label>Category*</label>
<select name="category_id" id="category_id"value="<?php echo $category_id?>" required>
	<?php
	foreach($category_value as $value){?>
	<option <?php if($category_id==$value["id"]){echo 'selected="selected"';} ?>value=<?php print_r($value["id"]); ?> ><?php print_r($value["category_name"]); ?></option>
<?php	
}
?>	
	
</select>
<label>Expiry Date</label>
<input type="date" name="expiry_date"value="<?php echo $expiry_date ?>">
<label>Description</label>
<input type="text" name="description"value="<?php echo $description ?>" required>
<label>Tags*</label>
<input type="text" name="tag" value="<?php echo $tag ?>">
<input type="submit" name="saveitem" value="Add Item">
</form>
<?php }?>

</body>
</html>