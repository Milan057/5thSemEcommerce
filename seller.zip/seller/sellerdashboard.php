<?php
session_start();
include '../connection.php';

if(!isset($_SESSION['seller_id'])){
	die("Login Required! <a href='"."../loginform.php'>Click Here</a>"); 
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<p>Hello <?php echo $_SESSION['seller_name']?> </p>
<input type="submit" id="additem_btn" name="additem_btn" value="Add Item" onclick="additem()">
<input type="submit" id="myitem_btn" name="myitem_btn" value="My Items" onclick="myitems()">
</body>
<script type="text/javascript">
function additem(){
	window.location="additem.php?option=1";
}	
function myitems(){
	window.location="myitems.php";
}

</script>
</html>